/**
 * 
 */
package org.hwufei.edu.course.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.hwufei.edu.course.domain.Course;
import org.hwufei.edu.course.service.CourseService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:17:11
 */
@RestController
@RequestMapping("/course")
public class CourseController {

	@Resource
	CourseService courseService;
	
	@RequestMapping("/list")
	public List<Course> getCourses(){
		return courseService.getCourses();
	}
	
}
