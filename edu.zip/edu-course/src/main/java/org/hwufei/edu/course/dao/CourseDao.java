/**
 * 
 */
package org.hwufei.edu.course.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hwufei.edu.course.domain.Course;
import org.springframework.stereotype.Repository;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:19:51
 */
@Repository
public class CourseDao {

	@Resource
	DataSource dataSource;
	
	public List<Course> getCourses(){
		List<Course> courses = new ArrayList<Course>();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select * from course");
			rs = ps.executeQuery();
			while(rs.next()){
				Course course = new Course();
				course.setId(rs.getInt("id"));
				course.setName(rs.getString("name"));
				course.setUrl(rs.getString("url"));
				course.setDescription(rs.getString("description"));
				course.setCover(rs.getString("cover"));
				course.setPrice(rs.getBigDecimal("price"));
				courses.add(course);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			close(rs, ps, connection);
		}
		return courses;
	}
	
	public static void close(AutoCloseable...autoCloseables){
		for(AutoCloseable autoCloseable : autoCloseables){
			if(autoCloseable != null){
				try {
					autoCloseable.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
