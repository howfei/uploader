/**
 * 
 */
package org.hwufei.edu.course.service;

import java.util.List;

import javax.annotation.Resource;

import org.hwufei.edu.course.dao.CourseDao;
import org.hwufei.edu.course.domain.Course;
import org.springframework.stereotype.Service;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:22:51
 */
@Service
public class CourseService {

	@Resource
	CourseDao dao;
	
	public List<Course> getCourses(){
		return dao.getCourses();
	}
}
