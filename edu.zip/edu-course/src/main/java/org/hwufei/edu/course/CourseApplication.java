/**
 * 
 */
package org.hwufei.edu.course;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import com.jolbox.bonecp.BoneCPConfig;
import com.jolbox.bonecp.BoneCPDataSource;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:17:11
 */
@EnableDiscoveryClient
@SpringBootApplication
public class CourseApplication {

	/**
	 * 功能说明：<br>
	 * @param args
	 * void
	 */
	public static void main(String[] args) {
		new SpringApplicationBuilder(CourseApplication.class).web(true).run(args);
	}

	@Bean
	public DataSource getDataSource(){
		BoneCPConfig config = new BoneCPConfig();
		config.setUsername("root");
		config.setPassword("root");
		config.setJdbcUrl("jdbc:mysql://localhost/my?useUnicode=true&amp;characterEncoding=utf-8");
		DataSource dataSource = new BoneCPDataSource(config);
		return dataSource;
	}
}
