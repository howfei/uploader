/**
 * 
 */
package org.hwufei.user;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hwufei.edu.user.UserApplication;
import org.hwufei.edu.user.dao.UserDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 说明:
 * 
 * @author howsun ->[howsun.zhang@gmail.com]
 * @version 1.0
 *
 * 2017年9月2日 下午5:04:55
 */
@RunWith(SpringRunner.class)
@SpringBootConfiguration
@SpringBootTest(classes = UserApplication.class)
public class BaseTest {

	@Resource
	UserDao userDao;
	
	@Test
	public void test(){
		System.out.println(userDao.getUsers());
	}
}
