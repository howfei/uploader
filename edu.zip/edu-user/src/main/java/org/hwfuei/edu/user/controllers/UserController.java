/**
 * 
 */
package org.hwfuei.edu.user.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.hwufei.edu.user.domain.User;
import org.hwufei.edu.user.service.UserService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午4:55:45
 */
@RestController
@RequestMapping("/user")
public class UserController {

	@Resource
	UserService userService;
	
	@RequestMapping("/list")
	public List<User> getUsers(){
		return userService.getUsers();
	}
}
