/**
 * 
 */
package org.hwufei.edu.user.util;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午4:53:22
 */
public class IOUtil {

	public static void close(AutoCloseable...autoCloseables){
		for(AutoCloseable autoCloseable : autoCloseables){
			if(autoCloseable != null){
				try {
					autoCloseable.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
