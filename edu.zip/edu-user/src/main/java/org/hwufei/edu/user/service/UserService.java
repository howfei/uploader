/**
 * 
 */
package org.hwufei.edu.user.service;

import java.util.List;

import org.hwufei.edu.user.dao.UserDao;
import org.hwufei.edu.user.domain.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午4:54:49
 */
@Service
public class UserService {

	@Resource
	UserDao dao;
	
	public List<User> getUsers(){
		return dao.getUsers();
	}
}
