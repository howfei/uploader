/**
 * 
 */
package org.hwufei.edu.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hwufei.edu.user.domain.User;
import org.hwufei.edu.user.util.IOUtil;
import org.springframework.stereotype.Repository;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午4:45:49
 */
@Repository
public class UserDao {

	@Resource
	DataSource dataSource;
	
	public List<User> getUsers(){
		List<User> users = new ArrayList<User>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select * from user");
			rs = ps.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setRealName(rs.getString("real_name"));
				user.setSex(rs.getString("sex"));
				user.setTel(rs.getString("tel"));
				users.add(user);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			IOUtil.close(rs, ps, connection);
		}
		
		return users;
	}
}
