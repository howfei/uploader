/**
 * 
 */
package org.hwufei.edu.user;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import com.jolbox.bonecp.BoneCPConfig;
import com.jolbox.bonecp.BoneCPDataSource;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午4:57:39
 */
@EnableDiscoveryClient
@SpringBootApplication
public class UserApplication {

	/**
	 * 功能说明：<br>
	 * @param args
	 * void
	 */
	public static void main(String[] args) {
		new SpringApplicationBuilder(UserApplication.class).web(true).run(args);
	}

	/**
	 * 
	 * 功能说明：<br>
	 * <bean id="dataSource" class="">
	 * </bean>
	 * @return
	 * DataSource
	 */
	@Bean
	public DataSource getDataSource(){
		BoneCPConfig config = new BoneCPConfig();
		config.setUsername("root");
		config.setPassword("root");
		config.setJdbcUrl("jdbc:mysql://localhost/my?useUnicode=true&amp;characterEncoding=utf-8");
		DataSource dataSource = new BoneCPDataSource(config);
		return dataSource;
	}
}
