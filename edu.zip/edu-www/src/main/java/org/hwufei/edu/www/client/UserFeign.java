/**
 * 
 */
package org.hwufei.edu.www.client;

import java.util.List;

import org.hwufei.edu.user.domain.User;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:59:22
 */
@FeignClient("edu-user-server")
public interface UserFeign {

	@RequestMapping("/user/list")
	public List<User> getUsers();
}
