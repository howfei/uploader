/**
 * 
 */
package org.hwufei.edu.www.controller;

import javax.annotation.Resource;

import org.hwufei.edu.www.client.UserFeign;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:57:19
 */
@Controller
@RequestMapping("/user")
public class UserController {

	@Resource
	UserFeign userFeign;
	
	@RequestMapping("/list")
	public String list(Model model){
		model.addAttribute("users", userFeign.getUsers());
		return "user_list";
	}
}
