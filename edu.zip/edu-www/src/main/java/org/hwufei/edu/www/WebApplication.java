/**
 * 
 */
package org.hwufei.edu.www;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午6:09:24
 */
@EnableFeignClients(basePackages = "org.howsun.edu.www.client")
@EnableDiscoveryClient
@EnableEurekaClient
@SpringBootApplication
public class WebApplication{

	/**
	 * 功能说明：<br>
	 * @param args
	 * void
	 */
	public static void main(String[] args) {
		new SpringApplicationBuilder(WebApplication.class).web(true).run(args);
	}

}
