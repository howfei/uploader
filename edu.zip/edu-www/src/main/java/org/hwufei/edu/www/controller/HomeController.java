/**
 * 
 */
package org.hwufei.edu.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 说明:
 * 
 * @author hwufei ->[hwufei@gmail.com]
 * @version 1.0
 *
 * 2017年6月2日 下午5:34:26
 */
@Controller
public class HomeController {

	@RequestMapping({"/", "/index", "/home"})
	public String home(){
		return "home";
	}
}
